Demo dataset for the USB Security Auditor. All files are harmless.
