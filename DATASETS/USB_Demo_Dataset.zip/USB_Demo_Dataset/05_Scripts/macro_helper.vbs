MsgBox "Demo script"
