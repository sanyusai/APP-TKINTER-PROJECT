@echo off
echo Backing up files (demo only)
