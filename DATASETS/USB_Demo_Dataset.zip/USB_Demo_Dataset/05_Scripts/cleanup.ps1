Write-Host 'Demo cleanup script'
