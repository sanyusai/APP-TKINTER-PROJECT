# USB Security Auditor: Demo Dataset

`USB_Demo_Dataset/` is a fake "USB drive" with **70 harmless files** in 8 folders and 4 levels of nesting.
Nothing in it can harm a computer: the "executables" contain only header bytes and no program code,
and the scripts only print text. Files are never run by the auditor, only read.

## How to use it
1. Unzip this archive anywhere (Desktop is fine).
2. Start the app: `python main.py` (macOS: activate your venv first).
3. **Select Device** -> **Browse Folder...** -> choose the `USB_Demo_Dataset` folder.
4. Optional, for the "real USB" demo: copy the `USB_Demo_Dataset` folder onto a pen drive, plug it in,
   then use **Refresh Devices** and pick the drive.
5. On the **File Explorer** page, set **Large-file threshold = 1 MB** and keep "Include sub-folders" ticked.
6. Click **Analyse 70 Files**.

## Expected result (roughly)
| Level | Files |
|-------|-------|
| High concern | 1 |
| Elevated concern | 3 |
| Review recommended | 12 |
| Low concern | 54 |
| Overall verdict | **High concern** (highest score 75/100) |

Random-data files get a different SHA-256 on each copy of the dataset, so hashes will differ from run to run.
The scores and flags stay the same.

## What each folder demonstrates
| Folder | Contents | What the auditor should show |
|--------|----------|------------------------------|
| `01_Documents` | txt, csv, pdf, docx, xlsx, pptx, a Hindi-named file, 3 levels of sub-folders | All **Low (0)**. Shows clean files, Unicode filenames and recursion. |
| `02_Photos_Media` | jpg, png, gif, mp3 | All **Low (0)**. Signatures match the extensions. |
| `03_Projects` | py, html, css, md, zip, a `.js` file | Clean; only `app.js` scores 10 (scripts can run code). |
| `04_Installers` | exe, dll, msi | Valid-looking `.exe` scores 10. `driver_pack.dll` scores 35, and the `.msi` with random data scores 20. |
| `05_Scripts` | bat, ps1, sh, vbs, empty .ps1 | Script extensions score 10. The empty script scores 15. |
| `06_Suspicious` | disguised and double-extension files | **The main demo.** See the table below. |
| `07_Backups_Large` | 2.5 to 6 MB files, 1 empty txt | The size check fires at a 1 MB threshold (+5). |
| `08_Nested` | 4 folders deep | Shows the recursive scan; one bat scores 10. |
| root | `autorun.inf`, `launcher.exe`, `Thumbs.db`, `.DS_Store` | `autorun.inf` and `launcher.exe` each score 10. |

## The `06_Suspicious` folder: files to click on during the viva
| File | Score | Why it is flagged |
|------|-------|-------------------|
| `.hidden_invoice_2026.pdf.exe` | **75 High** | Hidden file + double extension + not a real exe + very random data + large. The "everything wrong" file. |
| `update_installer.pdf.exe` | **65 Elevated** | Double extension + broken PE header + high entropy. |
| `crack_tool.txt.exe`, `free_wallpaper.jpg.exe` | **65 Elevated** | Same pattern with different decoys. |
| `empty_installer.exe` | 40 | An empty file that claims to be a program. |
| `broken_installer.exe`, `fake_driver.dll` | 35 | Plain text pretending to be a Windows program. |
| `invoice_march.pdf.exe`, `salary_report.xlsx.exe`, `holiday_photo.jpg.scr`, `resume_final.docx.bat` | 30 | Classic double-extension tricks. |
| `song_download.mp3` | 25 | An "MP3" whose content starts with `MZ` (a Windows program signature). |
| `vacation_pic.png`, `important_notes.pdf` | 20 | A Windows program hidden inside an image or PDF name (magic-byte mismatch). |
| `random_payload.bin`, `encrypted_backup.dat` | 10 | High entropy only (looks encrypted or packed). |
| `autorun.inf` | 10 | Autorun file: the classic USB-worm launcher. |
| `sample.exe.txt` | 0 | **False-positive example**: looks scary but is plain text. The last extension decides. |

## Suggested 5-minute demo flow
1. **Dashboard** -> *Start New Scan*.
2. **Select Device** -> Browse Folder -> `USB_Demo_Dataset` -> Continue.
3. **File Explorer** -> search `exe`, filter by type, click a column heading to sort, set threshold to 1 MB -> *Analyse*.
4. **Analysis Results** -> watch the progress bar; click `.hidden_invoice_2026.pdf.exe`; double-click it for the details window (checks table, evidence, SHA-256, recommendation). Then open `sample.exe.txt` to show a harmless file.
5. **Reports** -> *Generate PDF Report* -> open the PDF (executive summary, detailed findings). Also show the history list and CSV export.

## Notes
* **Windows Defender / antivirus:** the fake `.exe`, `.scr` and `.dll` files in `06_Suspicious` and `04_Installers` may be quarantined
  because they look like programs. This is a false alarm. If it happens, add the folder as an exclusion, or unzip the archive again.
* Want a smaller or different dataset? The generator script is available on request.
